#include<stdio.h>
#include"two.h"

int main(m)
{
	int time;
	printf("�� �Է�");
	scanf_s("%d", &time);
	second(time);
	printf("\n%d", m);
}