#pragma once
int time();
